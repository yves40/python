## Node.js Mid-Tier Restful API

### Launch Node.js API
Open a prompt and navigate to dino-date/nodejs
```
node server.js
```
DinoDate (Node.js) will be
```
http://localhost:3000/#/
```
### Troubleshooting

### [Restful API Function Mapping](https://github.com/oracle/dino-date/tree/master/RestfulAPI.md)

### [License](https://github.com/oracle/dino-date/tree/master/LICENSE)
Copyright (c) 2016 Oracle and/or its affiliates
The MIT License (MIT)