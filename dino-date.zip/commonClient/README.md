## Common Client Pages Used by All Mid-Tier Restful Interfaces.

The common client is only as a user friendly front end for the Restful API layers.

See the language folders for example code.

