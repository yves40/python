'use strict';
/*
Copyright (c) 2016, Oracle and/or its affiliates. 
All rights reserved.
*/

angular.module('dinoDateApp')

  .controller('HomeCtrl', function () {
    this.val = {};
    this.func = function() {};
  });
