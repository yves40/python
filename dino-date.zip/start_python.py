'''
Copyright (c) 2016, Oracle and/or its affiliates. 
All rights reserved.
'''
import sys
sys.path.append('python')
import app.py
