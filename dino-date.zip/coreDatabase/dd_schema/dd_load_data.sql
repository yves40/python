SET DEFINE OFF;
BEGIN
  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Aaron');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Aaron');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Alan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Albert');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Alice');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Amanda');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Amy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Andrea');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Andrew');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Angela');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ann');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Anna');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Anne');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Annie');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Anthony');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Antonio');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Arthur');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ashley');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Barbara');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Benjamin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Betty');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Beverly');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Billy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Bobby');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Bonnie');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Brandon');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Brenda');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Brian');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Bruce');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Carl');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Carlos');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Carol');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Carolyn');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Catherine');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Charles');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Cheryl');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Chris');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Christina');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Christine');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Christopher');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Clarence');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Craig');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Cynthia');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Daniel');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','David');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Deborah');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Debra');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Denise');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Dennis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Diana');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Diane');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Donald');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Donna');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Doris');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Dorothy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Douglas');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Earl');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Edward');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Elizabeth');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Emily');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Eric');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ernest');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Eugene');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Evelyn');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Frances');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Frank');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Fred');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Gary');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','George');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Gerald');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Gloria');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Gregory');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Harold');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Harry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Heather');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Helen');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Henry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Howard');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Irene');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jack');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jacqueline');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','James');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jane');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Janet');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Janice');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jason');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jean');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jeffrey');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jennifer');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jeremy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jerry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jesse');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jessica');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jimmy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Joan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Joe');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','John');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Johnny');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jonathan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Jose');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Joseph');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Joshua');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Joyce');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Juan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Judith');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Judy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Julia');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Julie');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Justin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Karen');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Katherine');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Kathryn');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Kathy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Keith');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Kelly');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Kenneth');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Kevin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Kimberly');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Larry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Laura');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Lawrence');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Lillian');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Linda');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Lisa');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Lois');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Lori');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Louis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Louise');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Margaret');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Maria');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Marie');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Marilyn');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Mark');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Martha');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Martin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Mary');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Matthew');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Melissa');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Michael');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Michelle');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Mildred');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Nancy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Nicholas');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Nicole');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Norma');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Pamela');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Patricia');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Patrick');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Paul');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Paula');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Peter');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Philip');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Phillip');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Phyllis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Rachel');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ralph');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Randy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Raymond');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Rebecca');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Richard');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Robert');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Robin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Roger');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ronald');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Rose');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Roy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ruby');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Russell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ruth');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Ryan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Samuel');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Sandra');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Sara');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Sarah');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Scott');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Sean');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Sharon');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Shawn');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Shirley');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Stephanie');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Stephen');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Steve');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Steven');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Susan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Tammy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Teresa');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Terry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Theresa');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Thomas');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Timothy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Tina');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Todd');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Victor');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Virginia');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Walter');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Wanda');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Wayne');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','William');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('first_name','Willie');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Adams');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Alexander');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Allen');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Alvarez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Anderson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Andrews');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Armstrong');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Arnold');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Austin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bailey');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Baker');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Banks');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Barnes');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bennett');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Berry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bishop');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Black');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bowman');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Boyd');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bradley');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Brooks');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Bryant');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Burke');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Burns');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Burton');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Butler');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Campbell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Carpenter');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Carr');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Carroll');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Carter');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Castillo');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Chapman');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Chavez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Clark');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Cole');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Coleman');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Collins');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Cook');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Cooper');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Cox');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Crawford');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Cruz');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Cunningham');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Daniels');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Davis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Day');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Dean');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Diaz');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Dixon');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Duncan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Dunn');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Edwards');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Elliott');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ellis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Evans');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ferguson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Fernandez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Fields');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Fisher');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Flores');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ford');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Foster');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Fowler');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Fox');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Franklin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Frazier');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Freeman');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Fuller');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Garcia');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gardner');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Garrett');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Garza');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','George');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gibson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gilbert');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gomez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gonzales');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gonzalez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gordon');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Graham');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Grant');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Green');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Greene');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Griffin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Gutierrez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hall');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hamilton');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hansen');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hanson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Harper');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Harris');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Harrison');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hart');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Harvey');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hawkins');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hayes');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Henderson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Henry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hernandez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hicks');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hill');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Holmes');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Howard');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Howell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hudson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hughes');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hunt');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Hunter');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Jackson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Jacobs');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','James');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Jenkins');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Johnson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Jones');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Jordan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Kelley');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Kennedy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Kim');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','King');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Knight');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lane');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Larson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lawrence');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lawson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lee');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lewis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Little');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Long');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lopez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Lynch');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Marshall');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Martin');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Martinez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Mason');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Matthews');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Mccoy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Mcdonald');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Medina');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Mendoza');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Meyer');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Miller');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Mills');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Mitchell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Montgomery');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Moore');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Morales');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Moreno');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Morgan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Morris');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Morrison');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Murphy');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Murray');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Myers');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Nelson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Nguyen');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Nichols');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Oliver');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Olson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ortiz');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Owens');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Palmer');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Parker');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Patterson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Payne');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Perez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Perkins');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Perry');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Peters');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Peterson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Phillips');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Pierce');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Porter');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Powell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Price');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ramirez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ramos');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ray');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Reed');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Reid');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Reyes');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Reynolds');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Rice');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Richards');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Richardson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Riley');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Rivera');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Roberts');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Robertson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Robinson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Rodriguez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Rogers');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Romero');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Rose');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ross');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ruiz');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Russell');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ryan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Sanchez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Sanders');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Schmidt');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Scott');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Shaw');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Simmons');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Simpson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Sims');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Smith');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Snyder');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Spencer');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Stanley');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Stephens');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Stevens');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Stewart');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Stone');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Sullivan');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Taylor');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Thomas');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Thompson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Torres');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Tucker');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Turner');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Vasquez');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wagner');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Walker');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wallace');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Ward');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Warren');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Washington');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Watkins');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Watson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Weaver');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Webb');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Welch');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wells');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','West');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wheeler');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','White');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Williams');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Williamson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Willis');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wilson');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wood');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Woods');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Wright');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('last_name','Young');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Afraid of earthquakes? Then stay away from me. My love will make you shake all over.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Afraid of fire? Then stay away from me. My love will make you burn.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Afraid of floods? Then stay away from me. My love will wash over you like a tidal wave.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Before I go to sleep, I like to sing myself a lullaby. I''ll sing one for you, too.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Dad says I should be just like him when I grow up. I said "No thanks!"');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Dad says that you can never go wrong by talking about yourself, so you''ll hear lots about me.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Dinosaur haiku, Fills my heart with love for you, Please don''t run away.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Do you see the living shapes in clouds? I do! If that doesn''t scare you, send me a message.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Don''t be afraid of my great big teeth, they only grin in happiness at seeing you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Gondwanland is a bit isolated, but I bet it''s much nicer than Antarctica.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I admit it: I am nervous about meeting new dinosaurs. So if you are kind and careful, get in touch.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I am grateful for every new morning, and not being food for a bigger dinosaur.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I can''t promise to remember your name, but I''ll never forget your face.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I confess: I am so clumsy I trip over my own paws. Can you make me agile with your love?');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I dream in color, I eat in black and white.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I hate to climb trees, but love to wallow in the mud.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I live among the trees, and love among the rocks.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I live for the moment and worry about tomorrow, tomorrow.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I live in the water, but also climb on shore in search of dry love.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I love the chase almost as much as the pounce.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I love to fly above the T-Rexes and laugh at them - ha, you''ll never catch me!');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I love to take a swim in rivers and oceans, but hate to put my big head under water.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I''m just a little critter and hide inside rotten trees - come rot with me!');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','I''ve been burned before (by wildfire), I can''t afford to be burned again.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If I could fly, I would fly to you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If I could grin, I''d be grinning every time I see your face.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If I could turn on the television, all I would want to see is you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If I had fingers, I would write you a haiku.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If I had opposable thumbs, I would make a picture frame and put you in it.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If we had books, I would love to read books and discuss plot intricacies.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If you like running up hills more than you like tumbling down, get in touch.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','If you love to take your time chewing bark off trees, you''re the dino for me.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Looking for a dinosaur who doesn''t mind a hug.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Love is a many splendored thing and so am I.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','My mother raised me to respect the other sex, so have no fear: I will treat you right!');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','No need to hide when I stroll into your neighborhood. I want to love, not eat.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Nothing better than a quiet nap on a big warm rock.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','OK, so I don''t have any legs or arms. I am still full of love for you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Roses are red, if your eyes are blue, then you look like my mom, and I love you, too.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Sleep during the day, play at night? Me, too, let''s cavort under the stars!');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Some dinosaurs only live in the moment. I like to live in a future - with you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','The best place to hug is when we are sunk in the mud up to our neck. Join me?');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','The best place to kiss is underwater. Join me?');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','The bigger you are, the bigger your heart. I am the biggest dinosaur there is. Check out my heart!');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','The first thing I do after waking up is face the sun and offer my thanks.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','The only thing more beautiful than a bright yellow sunrise is a sunrise spent with you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','The only thing more beautiful than a red-soaked sunset is a sunset spent with you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','What if we had just one more day to live and love? Would you spend it with me?');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','When a volcano erupts nearby, it reminds me of how my heart pounds when I think of you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','When it comes to dinosaur lovin'', you won''t find anyone better than me!');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','When it rains, I get wet. When it rains love, I get warm all over.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','When the wind whistles through the trees, my heart soars to the sky.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','While it is true that I spit venom, I would never spit at you.');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','Why live a lonely life, when you can spend your days with me?');

  INSERT INTO dd_seed_data (data_type,data)
                  VALUES ('sentence','You cannot change the past, but you can always change the future.');

  COMMIT;
END;
/

BEGIN
   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Stegosaurus', 23, 2);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Apatosaurus', 65, 25);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Triceratops', 25, 5);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Tyrannosaurus Rex', 45, 7);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Spinosaurus', 56, 6);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Velociraptor', 6, .2);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Brachiosaurus', 83, 50);

   INSERT
     INTO dd_dinosaurs (species_name,
                        average_length_in_feet,
                        average_weight_in_tons)
   VALUES ('Allosaurus', 33, 3);

   COMMIT;
END;
/

/*-------------------------------------------------------------------------------
 *
 * Create User Data
 */

DECLARE
   l_id   INTEGER;

   PROCEDURE add_member (location_id_in    IN INTEGER,
                         species_name_in   IN VARCHAR2,
                         dino_name_in      IN VARCHAR2,
                         email_in          IN VARCHAR2,
                         bio_in            IN CLOB)
   IS
      l_id   INTEGER;
   BEGIN
      INSERT INTO dd_members (dinosaur_id,
                              location_id,
                              dino_name,
                              email,
                              subscription_status,
                              about_yourself)
           VALUES (dd_dino_id_from_name (species_name_in),
                   location_id_in,
                   dino_name_in,
                   email_in,
                   'V',
                   bio_in)
        RETURNING member_id
             INTO l_id;

      INSERT INTO dd_messages (from_member_id,
                               to_member_id,
                               subject,
                               message_contents)
              VALUES (
                        dd_admin_pkg.c_admin_id,
                        l_id,
                        'Welcome to DinoDate!',
                        'When it comes to dinosaurs and love, DinoDate is the place to be!');
   END;
BEGIN
   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Sturt National Park',
                'Tibooburra',
                'NSW',
                '2880',
                'Australia',
                dd_degree_to_sdo ('29-05-37-S', '141-30-31-E'))
     RETURNING location_id
          INTO l_id;

   /* Set up admin member */
   INSERT INTO dd_members (member_id,
                           dinosaur_id,
                           location_id,
                           dino_name,
                           email,
                           subscription_status,
                           about_yourself)
        VALUES (dd_admin_pkg.c_admin_id,
                dd_dino_id_from_name ('Stegosaurus'),
                l_id,
                'Admin',
                'admin@example.com',
                'V',
                'Doing whatever it takes');

   add_member (
      l_id,
      'Stegosaurus',
      'Bob',
      'bob@example.com',
         'I love the outdoors and I''m looking for another dinosaur who doesn''t just want to sit around '
      || 'and snack on treetops. I want some adventure and I want to see new places. '
      || 'If you are also a dino between 25 and 35 tons, with a desire to roam '
      || 'through the shale, get in touch!');
   add_member (
      l_id,
      'Apatosaurus',
      'Sally',
      'sally@example.com',
         'Looking for a friendly, active dinosaur who knows how to have a good time, hanging around '
      || 'in Gondwana. Eat a triceratops, '
      || 'chase a pterodactyl across a field, take a mud bath and then get a tan lying around in the sun. '
      || 'That''s my idea of a good day!
');
   add_member (
      l_id,
      'Triceratops',
      'Topsy',
      'topsy@example.com',
         'I''m a sucker for an honest dinosaur who lives in the moment. Don''t try to convince me that '
      || 'we''ll be around forever, '
      || 'that there will always be dinosaurs. Who knows? A meteor could crash into this planet any day now. '
      || 'I say: tell the truth and live life to the fullest!');

   add_member (
      l_id,
      'Apatosaurus',
      'Special',
      'special@example.com',
         '"Special"''s my nickname. Know why? Because I am special and perfect for you. Looking for a dinosaur with '
      || 'a large appetite for lots of fun and loving?  Then I want to meet you!');


   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Mungo National Park',
                'Mungo',
                'NSW',
                '2715',
                'Australia',
                dd_degree_to_sdo ('33-44-56-S', '143-08-08-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Spinosaurus',
      'Lakshmi',
      'lakshmi@example.com',
         'Looking for a a really loud manly dinosaur who loves a noisy lady dinosaur. '
      || 'I make a LOT of noise as I trounce through the brush and proud of it. '
      || 'When I walk, you can hear me for miles around. '
      || 'Does that intimidate you? Then no need to apply. But if you are confident of yourself, '
      || 'and ready to join an adventure seeker as I roam the world, get in touch.');
   add_member (
      l_id,
      'Velociraptor',
      'Juan',
      'juan@example.com',
         'I like a dinosaur who''s not afraid to get dirty when it comes to having fun. '
      || 'I like to romp in lakes and in mud. And she''s got to have a sense of humor.'
      || ' If some pterodactyl comes flying by and buzzes you, there''s no reason to get upset. Just enjoy the joke!');
   add_member (
      l_id,
      'Brachiosaurus',
      'Bradley',
      'bradley@example.com',
         'I am an active, outgoing, super-smart Brachiosaurus seeking a brainy introvert. '
      || ' Which means: I don''t like competition in the conversation. I love somebody who '
      || 'loves to listen to me!');
   add_member (
      l_id,
      'Allosaurus',
      'Allison',
      'Allison@example.com',
         'I like competitive and carnivorous dinosaurs. Sure, we could chase down a tasty snack and share it, '
      || 'but why not have a race and then fight to the death over whatever we catch? '
      || 'In the end there''ll be just one of us, '
      || 'but along the way we''ll have a lot of fun. I prefer dinosaurs in Gondwanland, '
      || 'but would settle for an occasional visit to Laurasia.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Flinders Ranges National Park',
                'Blinman',
                'SA',
                '5730',
                'Australia',
                dd_degree_to_sdo ('31-25-20-S', '138-42-18-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Tyrannosaurus Rex',
      'Yuang',
      'yuang@example.com',
         'Whenever other dinosaurs see me, they run. Sometimes I get so lonely. Don''t be afraid of me '
      || '(when I''m not hungry). I''ve got needs just like you, even if my teeth are as big as your '
      || 'paws and I could snap your backbone without any trouble.  '
      || 'I''ve got needs and you''ve got needs. So why not give me a try? I promise to have a big meal before our date.');
   add_member (
      l_id,
      'Velociraptor',
      'Val',
      'val@example.com',
         'Seems like most dinosaurs are content to eat, drink, evacuate, sleep, and do it all over again, '
      || 'repeat until death do you part. I''m not like that. I like to sing songs, tell stories, '
      || 'play with my food before I eat it, and have food fights. Are you a fun-loving dinosaur? '
      || 'If so, then I''d love to hear from you.');
   add_member (
      l_id,
      'Triceratops',
      'Tomas',
      'tomas@example.com',
         'I like sitting under shady trees and bathing in tar pits. Do you like tar pits? '
      || 'Smooth and cool, sure a little bit sticky, '
      || 'but it''s a great place to hang out. Care to join me? Then come visit me in Lorasia and '
      || 'we''ll suck on some eggs while rolling around in the tar.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Hattah-Kulkyne National Park',
                'Hattah',
                'VIC',
                '3501',
                'Australia',
                dd_degree_to_sdo ('34-41-14-S', '142-22-54-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Triceratops',
      'Happy',
      'happy@example.com',
         'I love sailing, sking and all outdoor sports.  I laugh, and laugh, laugh all day long. '
      || 'Everything I see is funny.  And I love the color red.  And green.');

   add_member (
      l_id,
      'Triceratops',
      'Ushan',
      'ushan@example.com',
         'My favorite number is 3. If you can guess why, then you love math, just like me. '
      || 'So if you are a nerdy dinosaur and would like to hang out in a mudbath discussing primes, get in touch.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Karijini National Park',
                'Banjima Drive',
                'WA',
                '6751',
                'Australia',
                dd_degree_to_sdo ('22-29-46-S', '118-23-50-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Velociraptor',
      'Flicker',
      'flicker@example.com',
         'I am moving fast. Don''t want to waste a moment. If you feel a similar urgency,'
      || 'like - who knows? - a meteor could wipe us out any minute now, then let''s try a date. REALLY SOON.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Mount Field National Park',
                '66 Lake Dobson Rd',
                'TAS',
                '7140',
                'Australia',
                dd_degree_to_sdo ('42-39-19-S', '146-35-15-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Apatosaurus',
      'SuperDino',
      'SuperDino@example.com',
         'That''s my nickname. Know why? Because I am a superior dinosaur, bettr than all the rest. '
      || 'And I am looking for another superior dinosaur to be my #2.');

   add_member (
      l_id,
      'Stegosaurus',
      'Steve',
      'steve@example.com',
         'I''m a shy Stego, looking for a plant-eating companion. I enjoy long '
      || 'walks in the brush and a good tummy rub. Don''t be intimidated by my '
      || 'spikes or sharp teeth; I''m a loveable dino underneath the scales.');


   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Coorong National Park',
                'Coorong',
                'SA',
                '5264',
                'Australia',
                dd_degree_to_sdo ('36-02-57-S', '139-33-13-E'))
     RETURNING location_id
          INTO l_id;


   add_member (
      l_id,
      'Tyrannosaurus Rex',
      'Donald',
      'donald@example.com',
         'I have a busy, demanding life. I hunt all day long for my big brood of Triceratops, '
      || 'and when the sun goes down, '
      || 'I like to relax with a tall glass of bubbling brew and share a story of two '
      || 'with my buds. But I get lonely sometime for the kind of loving only '
      || 'you can provide. So if your evenings are free and you like to hang out and chat, I''m the dino for you.');

   add_member (
      l_id,
      'Brachiosaurus',
      'Babylove',
      'babylove@example.com',
         'What can I say? My parents gave me that nickname when I was a little baby. '
      || 'That was a LOOOONG time ago. Now I eat trees for breakfast. Yum! Looking for another '
      || 'dino with a big appetite for food and life.');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Nullarbor National Park',
                '50B McKenzie Street',
                'Ceduna',
                'SA',
                '5690',
                'Australia',
                dd_degree_to_sdo ('31-23-55-S', '130-08-16-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Apatosaurus',
      'Applotomia',
      'applotomia@example.com',
         'I''m Appy. I''m a bit long for my age at 23 meters, but I keep nice '
      || 'and fit (I weigh only 16 tons). I''m a friendly dino who likes to keep '
      || 'fit swimming in marshes, lifting boulders with my tail, and picking '
      || 'brush with my friends. Seeking a properly fit companion who values a '
      || 'nice, strong tail.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Tarlo River National Park',
                'Big Hill',
                'NSW',
                '2579',
                'Australia',
                dd_degree_to_sdo ('34-30-07-S', '149-55-35-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Triceratops',
      'Trixie',
      'trixie@example.com',
         'I''m a spiky dino looking for another, compatible Tricera. I''m an ethical '
      || 'plant-eater seeking a plant-eating companion. Trying to keep your life '
      || 'full of excitement with this fresh set of horns? Call me, maybe.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Wollemi National Park',
                'Wollemi',
                'NSW',
                '2330',
                'Australia',
                dd_degree_to_sdo ('32-52-26-S', '150-29-32-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Brachiosaurus',
      'Brandy',
      'brandy@example.com',
         'I just want to put this out there: I hate shrubbery. So if you''re into '
      || 'that, stay away from me. I''m opinionated and a picky eater, but I''m a '
      || 'gal who knows what she wants. Take it or leave it, this girl is not '
      || 'changing for anyone.');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Litchfield National Park',
                'Litchfield Park Road',
                'Litchfield Park',
                'NT',
                '0822',
                'Australia',
                dd_degree_to_sdo ('13-16-45-S', '130-52-36-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Velociraptor',
      'Vick',
      'vick@example.com',
         'I like a girl who '
      || 'knows what she wants, especially when it comes to food. This guy is '
      || 'the whole package. You''ll love me - as long as you can handle whole lot of sharp teeth.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Uluru-Kata Tjuta National Park',
                'Yulara',
                'NT',
                '0872',
                'Australia',
                dd_degree_to_sdo ('25-18-44-S', '131-01-07-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Tyrannosaurus Rex',
      'Tyler',
      'tyler@example.com',
         'I have to confess, I''m still single because I don''t identify with my '
      || 'species. If dreams could come true, I would find myself with a lovely '
      || 'Spinosaurus lady who would understand my aversion to my violent and '
      || 'vulgar species-mates.');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Tully Gorge National Park',
                'Tully Falls Rd',
                'Koombooloomba',
                'QLD',
                '4872',
                'Australia',
                dd_degree_to_sdo ('17-35-30-S', '145-34-05-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Triceratops',
      'Tanya',
      'tanya@example.com',
         'Honestly, is there anyone on this site looking to be just friends? '
      || 'Hit me up.');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Magnetic Island National Park',
                'Magnetic Island',
                'Queensland',
                'QLD',
                '4819',
                'Australia',
                dd_degree_to_sdo ('19-08-09-S', '146-50-32-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Allosaurus',
      'Alberto',
      'alberto@example.com',
         'I''ve been around the block a few times, and I''m not sure where to go '
      || 'from here. All I want is a best friend, who''ll come live with me in my '
      || 'cave, who enjoys watching trees grow, and keeps up with the latest '
      || 'theories on the end of the world.');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Freycinet National Park',
                'Coles Bay Rd',
                'Coles Bay',
                'TAS',
                '7215',
                'Australia',
                dd_degree_to_sdo ('42-07-31-S', '148-17-54-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Spinosaurus',
      'Stacy',
      'stacy@example.com',
         'I''m a pretty cool gal seeking a pretty cool guy. When I''m not '
      || 'strolling the fields watching the trees grow, I enjoy debating the '
      || 'latest theories on the end of the world.');


   add_member (
      l_id,
      'Brachiosaurus',
      'Vim',
      'vim@example.com',
         'Best friends forever!  I like to read and sleep.  My favorite place to '
      || 'sleep is warm shale rock.');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Croajingolong National Park',
                'Gales Hill Track',
                'Wingan River',
                'VIC',
                '3891',
                'Australia',
                dd_degree_to_sdo ('37-43-00-S', '149-28-00-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Velociraptor',
      'Vincent',
      'vincent@example.com',
         'I''ve been a charmer since I hatched. This smooth fella is looking for '
      || 'a lady who likes to be taken out on the town and treated right, '
      || 'as only a Velociraptor can treat you.');

   add_member (
      l_id,
      'Allosaurus',
      'Nisha',
      'nisha@example.com',
         'I am a nut eater who flies long distances.  I want to meet an '
      || 'honest dino interested in talking and walking.  I like sleeping in trees.');

   INSERT INTO dd_locations (location_name,
                             --address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Organ Pipes National Park',
                'Keilor North',
                'VIC',
                '3036',
                'Australia',
                dd_degree_to_sdo ('37-40-07-S', '144-46-02-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Tyrannosaurus Rex',
      'Taystee',
      'taystee@example.com',
         'I''m a fast-paced Rex with a hardcore attitude. I''m looking for someone '
      || 'who can keep up with me. Call me if you are up to the challenge.');


   add_member (
      l_id,
      'Apatosaurus',
      'Mike',
      'mike@example.com',
         'Let''s have kids and teach them to climb trees and eat nuts.  I '
      || 'want a shiny friend who treats me right and gives me space.');


   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Little Desert National Park',
                'Western Hwy',
                'Dimboola',
                'VIC',
                '3414',
                'Australia',
                dd_degree_to_sdo ('36-36-24-S', '141-11-19-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Allosaurus',
      'Skippy',
      'skippy@example.com',
         'Let''s go paddling on the edge of lakes, take long strides under '
      || 'the green palm trees, and talk deep and meaningfully all night long.');


   add_member (
      l_id,
      'Stegosaurus',
      'Stella',
      'stella@example.com',
         'This small-town gal is looking to settle down with someone who likes '
      || 'to have a good time. I''m looking for a even-tempered, intelligent '
      || 'companion interested in having a family.');

   add_member (
      l_id,
      'Brachiosaurus',
      'Champ',
      'champ@example.com',
         'I would fly across the sky to care for you.  I love big green eyes '
      || 'and big spiky horns.  Honk! Honk!');

   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Fitzgerald River National Park',
                '120 Albany Hwy',
                'Centennial Park',
                'WA',
                '6330',
                'Australia',
                dd_degree_to_sdo ('33-56-51-S', '119-36-55-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Brachiosaurus',
      'Boshan',
      'boshan@example.com',
         'I''m a mathlete at heart, I know it''s hard for my friends to '
      || 'understand. I also enjoy long walks in the brush and climbing trees, but I LOVE performing math '
      || 'exercises with stones.');

   add_member (
      l_id,
      'Apatosaurus',
      'Lina',
      'lina@example.com',
         'I really want a friend who loves food.  Let''s go squashing in '
      || 'the mud at dusk and eat some succulent grass.  Lots of leaves too. '
      || 'I love eating leaves and grass and trees.  And ferns.  Lots of ferns.');


   INSERT INTO dd_locations (location_name,
                             address1,
                             city,
                             state,
                             postal_code,
                             country,
                             geometry)
        VALUES ('Kakadu National Park',
                'Kakadu Hwy',
                'Jabiru',
                'NT',
                '0886',
                'Australia',
                dd_degree_to_sdo ('12-16-16-S', '132-40-23-E'))
     RETURNING location_id
          INTO l_id;

   add_member (
      l_id,
      'Spinosaurus',
      'Spu',
      'spu@example.com',
         'Born and raised in Kakadu and here to stay. Looking for a fun-loving '
      || 'partner who likes to have a good time. I''m just a simple dinosaur, really.');


   add_member (
      l_id,
      'Spinosaurus',
      'Weili',
      'weili@example.com',
         'I''m looking for someone 40 tons big  who lives in pine trees and '
      || 'doesn''t mind the rain.  We would eat nuts and fruit and feed each '
      || 'other small wiggly things.');


   add_member (
      l_id,
      'Triceratops',
      'Bill',
      'bill@example.com',
         'I love the sunlight.  My skin is smooth and shiny.  I love anything '
      || 'that shines and sparkles.  I would give you diamonds and pearls and '
      || 'make you my special one.');

   add_member (
      l_id,
      'Spinosaurus',
      'Dot',
      'dot@example.com',
         'I like knitting sweaters and booties.  I would have lots of little '
      || 'tiny dinos with you and knit them all their clothes.  I only knit '
      || 'with red wool.  I want to meet a creative dinosaur who is good with kids.');

   COMMIT;
END;
/

BEGIN
   INSERT INTO dd_settings (setting_name,
                            char_value,
                            num_value,
                            date_value)
        VALUES ('max_members',
                NULL,
                10000,
                NULL);

   INSERT INTO dd_settings (setting_name,
                            char_value,
                            num_value,
                            date_value)
        VALUES ('validate_passwords',
                'n',
                NULL,
                NULL);

   COMMIT;
END;
/
SET DEFINE ON;