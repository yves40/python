**IMPORTANT - Please make sure you're using a database instance in which you can safely create a schema named DD.**
