set echo on

drop table mytab;
create table mytab (id number, data varchar2(20));

exit

